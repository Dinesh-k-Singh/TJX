﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using TJXChallenge.API.Controllers;
using Microsoft.Extensions.Configuration;

namespace TJXChallenge.Test.Controller.Test
{
    public class ProductContollerTest
    {
        
        public void ProductController_GetProducts_VallidateResult()
        {

            var product = new ProductController();
            var productList = product.GetProducts("USA");
            if (productList.Count > 0)
                Assert.True(true);
            else Assert.False(false);
        }
    }
}
