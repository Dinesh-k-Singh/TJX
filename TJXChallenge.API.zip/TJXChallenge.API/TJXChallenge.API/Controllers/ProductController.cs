﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using TJXChallenge.API.Model;
using TJXChallenge.API.DataAccessLayer;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Authorization;

namespace TJXChallenge.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [AllowAnonymous]
    [EnableCors]
    public class ProductController : ControllerBase
    {
        private readonly ILogger<ProductController> _logger;
        private readonly IConfiguration _configuration;

        public ProductController() { }

        [HttpGet]
        [EnableCors]
        public List<Product> GetProducts(string CountryCode = "USA")
        {

            Data Db = new Data();          
            return Db.GetProducts(CountryCode);

        }

        [HttpGet]
        public List<string> GetCountry()
        {

            Data Db = new Data();
            return Db.GetCountries();

        }
    }
}
